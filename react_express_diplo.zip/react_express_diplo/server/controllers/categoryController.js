const { Category } = require('../models/models');
const ApiError = require('../error/ApiError');

class CategoryController {
    // Создание категории
    async create(req, res, next) {
        try {
            const { name, parentId } = req.body; // parentId для подкатегорий
            const category = await Category.create({ name, parentId });
            return res.json(category);
        } catch (error) {
            console.error('Ошибка создания категории:', error); // Логирование ошибки
            next(ApiError.internal('Ошибка при создании категории'));
        }
    }
    

    // Получение всех категорий
    async getAll(req, res, next) {
        try {
            const categories = await Category.findAll();
            return res.json(categories);
        } catch (error) {
            next(ApiError.internal('Ошибка при получении категорий'));
        }
    }
}

module.exports = new CategoryController();
