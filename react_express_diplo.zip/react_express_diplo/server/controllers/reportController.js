const { Reports } = require('../models/models');
const ApiError = require('../error/ApiError');

class reportController {
    // Создание отчёта
    async create(req, res, next) {
        try {
            const { 
                type, // Тип операции (приход/расход)
                date, // Дата операции
                itemId, // ID товара
                skladId, // ID склада
                quantityBefore, // Количество до операции
                quantityAfter // Количество после операции
            } = req.body;

            const report = await Reports.create({
                type,
                date,
                itemId,
                skladId,
                quantityBefore,
                quantityAfter,
            });

            return res.json(report);
        } catch (error) {
            next(ApiError.internal('Ошибка при создании отчёта'));
        }
    }

    // Получение всех отчётов
    async getAll(req, res, next) {
        try {
            const reports = await Reports.findAll();
            return res.json(reports);
        } catch (error) {
            next(ApiError.internal('Ошибка при получении отчётов'));
        }
    }
}

module.exports = new reportController();
