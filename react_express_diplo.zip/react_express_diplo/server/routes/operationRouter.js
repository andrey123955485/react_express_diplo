const Router = require('express')
const operationController = require('../controllers/operationController')
const router = new Router()

router.post('/', operationController.create)
router.get('/', operationController.getAll)
router.get('/:id',)

module.exports = router