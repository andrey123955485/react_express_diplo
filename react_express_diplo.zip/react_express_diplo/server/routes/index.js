const Router = require('express')
const router = new Router()

const userRouter = require('./userRouter')
const skladRouter = require('./skladRouter')
const itemRouter = require('./itemRouter')
const categoryRouter = require('./categoryRouter')
const operationRouter = require('./operationRouter')
const reportRouter = require('./reportRouter')


router.use('/user', userRouter)
router.use('/sklad', skladRouter)
router.use('/item', itemRouter)
router.use('/category', categoryRouter)
router.use('/operation', operationRouter)
router.use('/report', reportRouter)


module.exports = router