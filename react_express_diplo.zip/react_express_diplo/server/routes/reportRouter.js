const Router = require('express')
const reportController = require('../controllers/reportController')
const router = new Router()

router.post('/', reportController.create)
router.get('/', reportController.getAll)
router.get('/:id',)

module.exports = router