require('dotenv').config()
const express = require('express')
const sequelize = require('./db')
const PORT = process.env.PORT || 5000
const models = require('./models/models')
const cors = require('cors')
const app = express()
const fileUpload = require('express-fileupload')
const router = require('./routes/index')
const errorHadler = require('./middleware/ErrorHandlingMiddleware')
const path = require('path')
app.use(cors())
app.use(express.json())
app.use(express.static(path.resolve(__dirname, 'static')))
app.use(fileUpload({}))
app.use('/api', router)



// Обработка ошибок, последний Middleware
app.use(errorHadler)


const start = async () => {
    try {
        await sequelize.authenticate(); // Проверяем подключение к базе данных
        console.log("Database connected successfully!");
        await sequelize.sync({ alter: true }); // Обновляет таблицы, если есть изменения в моделях
        console.log("Models synchronized with the database.");

        app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
    } catch (e) {
        console.log("Error starting the server:", e);
    }
};

start();

